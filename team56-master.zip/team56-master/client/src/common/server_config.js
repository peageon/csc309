export const SERVER_URL = "" // This is not needed for deployed app. Change in local environment if needed.
